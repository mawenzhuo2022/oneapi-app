export default {
  'component.tagSelect.expand': 'باز',
  'component.tagSelect.collapse': 'بسته ',
  'component.tagSelect.all': 'همه',
};
