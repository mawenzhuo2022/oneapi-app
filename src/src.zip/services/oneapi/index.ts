// @ts-ignore
/* eslint-disable */
// API 更新时间：
// API 唯一标识：
import * as analysisController from './analysisController';
import * as basicErrorController from './basicErrorController';
import * as interfaceInfoController from './interfaceInfoController';
import * as postController from './postController';
import * as userController from './userController';
import * as userInterfaceInfoController from './userInterfaceInfoController';
export default {
  analysisController,
  basicErrorController,
  interfaceInfoController,
  postController,
  userController,
  userInterfaceInfoController,
};
